//Matias Figueroa - Javier Gutierrez
class testColaBinomial{
	public static void main(String[] args)
	{
		int contador= 0;
		int a[] = {42,26,16,23,77,28,13,10,27,11,17,8,38,14,29,6,41,37,18,12,25};
		ColaBinomial b = new ColaBinomial();
		for (int j : a){
			b.Insert(j);
			contador++;
		}
		if (contador==0){
			b.Size();
		}else {
			System.out.println();
			b.Print();
			System.out.println("La cantidad de nodos del arbol es: " + b.Size());
			System.out.println();
			System.out.println();
			System.out.println("costo algorítmico de la propuesta:");
			System.out.println("La implementacion del metodo size() es de ");
			System.out.println("orden 0(n) ya que es de orden 1 hasta que llega a el while");
			System.out.println("el cual  itera a través de cada árbol");
			System.out.println("binomial en la cola si hay n árboles binomiales");
		}
	}
}
