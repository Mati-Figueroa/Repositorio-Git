public class Main {
    public static void main(String[] args) {
        System.out.println("En la página funciona.");
    }


    class Solucion { //pila
        public int maxDepth(String s) {
            int max=0;
            int paren=0;

            for (int i=0;i<s.length();i++){
                if (s.charAt(i)=='('){
                    paren++;
                }

                if(paren> max){
                    max=paren;
                }

                if(s.charAt(i)== ')'){
                    paren--;
                }

            }
            return max;
        }
    }
}