import java.util.LinkedList;

class cola { //cola
        private LinkedList<Integer> counter = new LinkedList<>();
        public RecentCounter() {

        }

        public int ping(int t) {
            counter.add(t);

            while (counter.peek() < t - 3000) {
                counter.poll();
            }
            return counter.size();
        }
    }
}
