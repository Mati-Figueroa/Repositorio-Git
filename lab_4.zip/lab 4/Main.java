import java.sql.SQLOutput;

public class Main {

    public static void main(String[] args) {
        ListaEnlazada lista = new ListaEnlazada();
        ListaEnlazada listaDos = new ListaEnlazada();

        // Agregar 10 elementos a la lista
        for (int i = 1; i <= 10; i++) {
            lista.agregarElemento((int)(Math.random()*100)+1);
            listaDos.agregarElemento((int)(Math.random()*100)+1);
        }



        System.out.println("");
        lista.ordenarLista();
        lista.promedioLista();
        int promedioUno = lista.promedioLista();
        listaDos.ordenarLista();
        lista.promedioLista();
        int promedioDos = lista.promedioLista();


        System.out.println("Lista Ordenada: ");
        lista.imprimirLista();
        listaDos.imprimirLista();

        ListaEnlazada terceraLista = new ListaEnlazada();
        Nodo actual = lista.cabeza;
        while (actual !=null){
            if(actual.dato > promedioUno){
                terceraLista.agregarElemento(actual.dato);
            }
            actual=actual.siguiente;

        }
        actual=listaDos.cabeza;
        while (actual !=null){
            if(actual.dato > promedioDos){
                terceraLista.agregarElemento(actual.dato);
            }
            actual=actual.siguiente;

        }
        System.out.println("Tercera Lista De menor a mayor");
        terceraLista.ordenarLista();
        terceraLista.imprimirLista();


    }


}