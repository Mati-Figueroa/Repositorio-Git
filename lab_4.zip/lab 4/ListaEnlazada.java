public class ListaEnlazada {
    Nodo cabeza;
    Nodo mayoria;

    public ListaEnlazada() {
        this.cabeza = null;
    }
    public void ListaMayor(){
        this.mayoria = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public void ordenarLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            Nodo menor = actual;
            Nodo nTemp = actual.siguiente;

            while (nTemp != null) {
                if (nTemp.dato < menor.dato) {
                    menor = nTemp;
                }
                nTemp = nTemp.siguiente;
            }

            int temp = actual.dato;
            actual.dato = menor.dato;
            menor.dato = temp;
            actual = actual.siguiente;
        }
    }

    public int promedioLista(){
        Nodo actual = cabeza;
        int suma = 0;
        int promedio;
        while (actual!= null){
            suma+= actual.dato;
            actual= actual.siguiente;
        }
        promedio= suma/10;
        System.out.println("promedio: "+ promedio);
        return promedio;
    }

    public void ordenarMayores() {
        Nodo actual = cabeza;
        Nodo mayor = mayoria;
        int promedio = promedioLista();
        while (actual != null) {
            mayor = actual;
            Nodo nTemp = actual.siguiente;

            while (nTemp != null) {
                if (nTemp.dato > promedio) {
                    mayor = nTemp;
                }
                nTemp = nTemp.siguiente;
                mayor = mayor.siguiente;
                if (mayor == null){

                }else {
                    System.out.print(mayor.dato + " ");
                    mayor = mayor.siguiente;
                }
            }

            actual = actual.siguiente;
            mayor =mayor.siguiente;
        }
    }

    public void agregarMayores(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (mayoria == null) {
            mayoria = nuevoNodo;
        } else {
            Nodo temp = mayoria;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }
    public void imprimirMayor() {
        Nodo mayor = cabeza;
        while (mayor != null) {
            System.out.print(mayor.dato + " ");
            mayor = mayor.siguiente;
        }
        System.out.println();
    }
}
