import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

class Nodo {
    int valor;
    int ID;

    public Nodo(int valor, int ID) {
        this.valor = valor;
        this.ID = ID;
    }
}

public class lista {
    public static void main(String[] args) {
        LinkedList<Nodo> listaEnlazada = new LinkedList<>();


        Random random = new Random();
        for (int i = 1; i < 11; i++) {
            int numeroAleatorio = random.nextInt(100);
            int posicion = i;
            Nodo nuevoNodo = new Nodo(numeroAleatorio, posicion);
            listaEnlazada.add(nuevoNodo);
        }


        System.out.println("Lista Original:");
        for (Nodo nodo : listaEnlazada) {
            System.out.println("ID: " + nodo.ID + ", Elemento: " + nodo.valor);
        }


        Collections.sort(listaEnlazada, (a,b)->Integer.compare(a.valor, b.valor));


        System.out.println("\nLista Ordenada:");
        for (Nodo nodo : listaEnlazada) {
            System.out.println("ID: " + nodo.ID + ", Elemento: " + nodo.valor);
        }
    }
}


