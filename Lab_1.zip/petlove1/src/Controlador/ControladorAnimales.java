//va a tener funcionalidades
package Controlador;

import Modelo.Gato;
import Modelo.General;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class ControladorAnimales {

//CRUD: CREATE - READ - UPDATE - DELETE

    Scanner tcld = new Scanner(System.in);

    public static ControladorAnimales instance = null;
    public static ArrayList<General> Animales = new ArrayList<>();
    public static ControladorAnimales getInstance(){
        if(instance == null){
            instance= new ControladorAnimales();
        }
        return instance;
    }

    public static General[] listarAnimales(){
        General[] arrayAnimales = new General [Animales.size()];
        arrayAnimales = Animales.toArray(arrayAnimales);
        return arrayAnimales;
    }

    //ELIMINAR GATITO
     public boolean eliminarAnimal(String nombre){
        for(General animal : Animales){
            if(animal.getNombre().equalsIgnoreCase(nombre)){
                Animales.remove(animal);
                return true;
            }
        }
        return false;
     }

    public void agregarAnimal(String nombreDueno, String tipo, String nombre, String color, int edad, LocalDate fecha) {
    Animales.add(new General(tipo,nombreDueno,nombre,color,edad,fecha));
    }
}
