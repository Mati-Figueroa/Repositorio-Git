package Vista;
import Controlador.ControladorAnimales;
import Modelo.General;

import java.sql.SQLOutput;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.Scanner;

public class Menu {

    private static Menu instance = null;

    public static Menu getInstance() {
        if (instance == null) {
            instance = new Menu();
        }
        return instance;
    }
    private boolean existe;

    Scanner tcld = new Scanner(System.in);

    public void menu() {
        int op;
        do {
            System.out.println(" ");
            System.out.println("***** SISTEMA DE FERRETERIA *****");
            System.out.println("** MENU DE OPCIONES **");
            System.out.println("1.- Ingresar nuevo Animal");
            System.out.println("2.- Dar de alta");
            System.out.println("3.- Listado de animales ingresados");
            System.out.println("4.- Salir");
            System.out.println("Ingrese una opción: ");
            op = tcld.nextInt();
            switch (op) {
                case 1:
                    CreaAnimal();
                    break;
                case 2:
                        EliminarAnimal();
                    break;
                case 3:
                    ListaAnimales();
                    break;
                case 4:
                    System.exit(0);
                    break;
            }
        } while (op != 4);


    }
    public void CreaAnimal() {
        String tipo;
        boolean esTipo;
        do {
            System.out.println("Ingrese que Animal entra (Perro/Gato/Conejo)");
            tipo = tcld.next();
            if (tipo.equalsIgnoreCase("Perro") || tipo.equalsIgnoreCase("Gato") || tipo.equalsIgnoreCase("Conejo")){
                esTipo = true;
            }else{
                System.out.println("Ingrese un animal valido");
                esTipo = false;
            }
        }while (esTipo == false );
        System.out.println("Ingrese nombre del Dueño");
        tcld.nextLine();
        String nombreDueno = tcld.nextLine();
        System.out.println("Nombre del "+tipo);
        String nombre = tcld.next();
        System.out.println("Color del "+tipo);
        String color = tcld.next();
        int edad;
        int dias;
        int meses;
        LocalDate fecha;
        do {
            System.out.println("Fecha de nacimiento del "+tipo+" (yyyy-MM-dd)");
            String fechaxd = tcld.next();
            DateTimeFormatter format = new DateTimeFormatterBuilder().append(DateTimeFormatter.ofPattern("yyyy-MM-dd")).toFormatter();
            fecha = LocalDate.parse(fechaxd, format);
            LocalDate fechaActual = LocalDate.now();
            Period periodo = Period.between(fecha, fechaActual);
           edad = periodo.getYears();
           meses = periodo.getMonths();
           dias = periodo.getDays();
           if (edad <0||dias <0 || meses <0){
               System.out.println("ingrese una fecha valida");
           }
        }while(edad <0||dias <0 || meses <0);
        ControladorAnimales.getInstance().agregarAnimal(nombreDueno,tipo, nombre,color,edad,fecha);
    }
    public void EliminarAnimal(){
        do {
            System.out.println("Que animalito se dara de alta?");
            String nombreAnimal = tcld.next();
            if (ControladorAnimales.getInstance().eliminarAnimal(nombreAnimal)) {
                existe = true;
                System.out.println("Adios " + nombreAnimal + " te echaremos de menos unu");
            } else {
                existe = false;
                System.out.println("error de registro");

            }
        }while (existe != true);





    }

    public void ListaAnimales() {
        General[] arrayAnimales = ControladorAnimales.getInstance().listarAnimales();
        System.out.printf("%-16s%-16s%-16s%-16s%-16s%-16s%n", "TIPO DE ANIMAL","NOMBRE DUEÑO","NOMBRE", "COLOR", "EDAD", "FECHA NACIMIENTO");
        for (General general : arrayAnimales ) {
            System.out.printf("%-16s%-16s%-16s%-16s%-16s%-16s%n", general.getNombreDueno(), general.getTipo(), general.getNombre(), general.getColor(), general.getEdad(), general.getFechaNacimiento());
        }
    }

}
