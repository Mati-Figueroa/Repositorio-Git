package Modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class General {
    private String nombreDueno;
    private String nombre;
    private String color;
    private int edad;
    private LocalDate FechaNacimiento;
    private String tipo;

    public General(String nombreDueno,String tipo, String nombre, String color, int edad, LocalDate fechaNacimiento) {
        this.nombreDueno = nombreDueno;
        this.tipo = tipo;
        this.nombre = nombre;
        this.color = color;
        this.edad = edad;
        FechaNacimiento = fechaNacimiento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombreDueno() {
        return nombreDueno;
    }

    public void setNombreDueno(String nombreDueno) {
        this.nombreDueno = nombreDueno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        if (edad < 1) {
            edad = 1;
        }
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public LocalDate getFechaNacimiento() {
        return FechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        FechaNacimiento = fechaNacimiento;
    }
}
