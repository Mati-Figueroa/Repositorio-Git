package Modelo;

import java.time.LocalDate;

public class Perro extends General {

    public Perro(String nombreDueno,String tipo, String nombre, String color, int edad, LocalDate fechaNacimiento) {
        super(nombreDueno,tipo, nombre, color, edad, fechaNacimiento);
    }
}
