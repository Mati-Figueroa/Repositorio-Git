public class Main {
    public static void main(String[] args) {
        Arbol arbol = new Arbol();

        arbol.insertar(10);
        arbol.insertar(5);
        arbol.insertar(15);
        arbol.insertar(3);
        arbol.insertar(7);


        System.out.print("Datos Nodos:");
        arbol.recorrerInorden();
        System.out.println();
    }
}