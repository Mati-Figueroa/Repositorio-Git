public class Arbol {
    Nodo raiz;

    public Arbol() {
        this.raiz = null;
    }

    public void insertar(int dato) {
        raiz = insertarRecursivo(raiz, dato);
    }

    private Nodo insertarRecursivo(Nodo nodo, int dato) {
        if (nodo == null) {
            return new Nodo(dato);
        }

        if (dato < nodo.dato) {
            nodo.izquierda = insertarRecursivo(nodo.izquierda, dato);
        } else if (dato > nodo.dato) {
            nodo.derecha = insertarRecursivo(nodo.derecha, dato);
        }

        return nodo;
    }

    public void recorrerInorden(){
        recorrerInordenRec(raiz);
        System.out.println("");
        int numeroDeNodos = contarNodos();
        System.out.println("Número de nodos: " + numeroDeNodos);
    }

    private void recorrerInordenRec(Nodo nodo){
        if(nodo != null){
            recorrerInordenRec(nodo.izquierda);
            System.out.print(nodo.dato+" ");
            recorrerInordenRec(nodo.derecha);
        }
    }

    public int contarNodos() {
        return contarNodosRecursivo(raiz);
    }

    private int contarNodosRecursivo(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }

        int contador = 1;

        contador += contarNodosRecursivo(nodo.izquierda);
        contador += contarNodosRecursivo(nodo.derecha);
        return contador;
    }
}
