public class ArbolBinarioBusqueda {
    Nodo raiz;

    public ArbolBinarioBusqueda() {
        raiz = null;
    }

    public void insertar(int dato) {
        raiz = insertarRecursivo(raiz, dato);
    }

    private Nodo insertarRecursivo(Nodo nodo, int dato) {
        if (nodo == null) {
            return new Nodo(dato);
        }

        if (dato < nodo.dato) {
            nodo.izquierda = insertarRecursivo(nodo.izquierda, dato);
        } else if (dato > nodo.dato) {
            nodo.derecha = insertarRecursivo(nodo.derecha, dato);
        }

        return nodo;
    }

    public int contarHojas() {
        return contarHojasRecursivo(raiz);
    }

    private int contarHojasRecursivo(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }


        if (nodo.izquierda == null && nodo.derecha == null) {
            return 1;
        }


        int hojasIzquierda = contarHojasRecursivo(nodo.izquierda);
        int hojasDerecha = contarHojasRecursivo(nodo.derecha);


        return hojasIzquierda + hojasDerecha;
    }
}


