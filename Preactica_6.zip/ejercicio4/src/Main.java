public class Main {
    public static void main(String[] args) {
        ArbolBinarioBusqueda arbol = new ArbolBinarioBusqueda();
        arbol.insertar(6);
        arbol.insertar(2);
        arbol.insertar(8);
        arbol.insertar(1);
        arbol.insertar(4);
        arbol.insertar(7);
        arbol.insertar(9);

        int hojas = arbol.contarHojas();
        System.out.println("Número de hojas en el árbol: " + hojas);
    }

}