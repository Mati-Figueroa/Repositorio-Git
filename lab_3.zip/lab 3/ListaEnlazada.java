public class ListaEnlazada {
    Nodo cabeza;

    public ListaEnlazada() {
        this.cabeza = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public void ordenarLista() {
        Nodo actual = cabeza;
        while (actual != null) {
            Nodo menor = actual;
            Nodo nTemp = actual.siguiente;

            while (nTemp != null) {
                if (nTemp.dato < menor.dato) {
                    menor = nTemp;
                }
                nTemp = nTemp.siguiente;
            }

            int temp = actual.dato;
            actual.dato = menor.dato;
            menor.dato = temp;

            actual = actual.siguiente;
        }
    }
}
