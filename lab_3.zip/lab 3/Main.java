import java.sql.SQLOutput;

public class Main {

    public static void main(String[] args) {
        ListaEnlazada lista = new ListaEnlazada();

        // Agregar 10 elementos a la lista
        for (int i = 1; i <= 10; i++) {
            lista.agregarElemento((int)(Math.random()*100)-1);
        }

        System.out.println("Lista Original: ");
        // Imprimir la lista
        lista.imprimirLista();

        System.out.println("");
        lista.ordenarLista();

        System.out.println("Lista Ordenada: ");
        lista.imprimirLista();

    }


}